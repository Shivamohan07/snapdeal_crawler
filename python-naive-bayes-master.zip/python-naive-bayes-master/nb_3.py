import re
import string
import csv
def remove_punctuation(s):
    """See: http://stackoverflow.com/a/266162
    """
    exclude = set(string.punctuation)
    return ''.join(ch for ch in s if ch not in exclude)

def tokenize(text):
    text = remove_punctuation(text)
    text = text.lower()
    return re.split("\W+", text)

def count_words(words):
    wc = {}
    for word in words:
        wc[word] = wc.get(word, 0.0) + 1.0
    return wc


from sh import find

# setup some structures to store our data
vocab = {}
word_counts = {
    "good": {},
    "bad": {},
    "snapdeal":{}
}
priors = {
    "buy": 0.,
    "dont": 0.,
  
}
docs = []
len_words=0
for f in find("sample-data"):
    f = f.strip()
    #print f
    if  f.endswith(".txt"):
    	fi=open(f).read()
    	words1 = tokenize(fi)
    	words1.remove('')
    	#print words1
    	len_words+=len(words1)
    	#print len_words
        counts1 = count_words(words1)
        #print "dfdf"
        #print counts1["bad"]
        try:
        	priors["buy"]+=counts1["buy"]
        except KeyError:
        	pass
        try:
        	priors["dont"]+=counts1["dont"]
        except KeyError:
        	pass
        #print priors["good"]
        #print priors["snapdeal"]
        for word, count in list(counts1.items()):
			# if we haven't seen a word yet, let's add it to our dictionaries with a count of 0
			if word not in vocab:
				vocab[word] = 0.0  # use 0.0 here so Python does "correct" math
			if word not in word_counts["good"]:
				word_counts["good"][word] = 0.0
			if word not in word_counts["bad"]:
				word_counts["bad"][word] = 0.0
			vocab[word] += count
			word_counts["good"][word] += count
			word_counts["bad"][word] +=count
print "Count of 'buy' word in review file",priors["buy"]
print "Count of 'dont' word in review file",priors["dont"]
#print len_words
prior_good = (priors["buy"] / len_words)
prior_bad = (priors["dont"] / len_words)
print "Probability of 'buy' word",prior_good
print "Probability of 'dont' word",prior_bad

new_doc = open("examples/XOLO Era 4G 8GB Black.txt").read()

words = tokenize(new_doc)

counts = count_words(words)

#print counts
import math

log_prob_bad = 0.0
log_prob_good = 0.0
log_prob_snapdeal = 0.0
#print sum(vocab.values())
for w, cnt in list(counts.items()):
    # skip words that we haven't seen before, or words less than 3 letters long
    if w not in vocab:
        continue

    p_word = vocab[w] / sum(vocab.values())
    #p_w_given_good = word_counts["good"].get(w, 0.0) / 
    p_w_given_good = word_counts["good"].get(w, 0.0) / sum(word_counts["good"].values())
    p_w_given_bad = word_counts["bad"].get(w, 0.0) / sum(word_counts["bad"].values())
    #p_w_given_snapdeal = word_counts["snapdeal"].get(w, 0.0) / sum(word_counts["snapdeal"].values())
    
    if p_w_given_good>0 and w=="buy":
        log_prob_good = math.log10(p_w_given_good / p_word)
        #print math.log10(cnt * p_w_given_dino / p_word)
    if p_w_given_bad>0 and w=="buy":
        log_prob_bad = math.log10(p_w_given_bad / p_word)
    #if p_w_given_snapdeal > 0:
    #    log_prob_snapdeal += math.log10(cnt * p_w_given_snapdeal / p_word)
print "Probability of buy when review is positive  :",math.exp(log_prob_good + math.log10(prior_good))
print "Probability of buy when review is negative  :",math.exp(log_prob_bad + math.log10(prior_bad))
#print("Score(snapdeal):", math.exp(log_prob_snapdeal + math.log10(prior_snapdeal)))
