# Naive Bayes in Python for snapdeal reviews


```bash
$ cd python-naive-bayes-master
$ python nb_3.py

Count of 'buy' word in review file 130.0
Count of 'dont' word in review file 38.0
Probability of 'buy' word 0.00319685233001
Probability of 'dont' word 0.000934464527235
Probability of buy when review is positive  : 0.0824735680434
Probability of buy when review is negative  : 0.0483428387864

```
Application of naive bayes theorem is as follows,
Probability of buy being written in positive manner is calculated using bayes theorem as shown below
P(good/buy)=    (P(buy/good) * P(good)) / P(buy)

The code currently checks only for word "buy" , user input for probablity calculation of the words in positive or negative manner will be added in code.

